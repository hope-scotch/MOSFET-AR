Developer: Sayantan Biswas
Unity Version: 2019.2.17
Vuforia Version: 8.5.9
Youtube Link: https://www.youtube.com/watch?v=-ytZ3yv3kbc&feature=youtu.be
Figure: 14.31 (Class 12)